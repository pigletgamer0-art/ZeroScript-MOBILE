package com.zeroscript.studio;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * Replaces the desktop "bridge": keeps the tool catalogue, answers the messages the
 * ZeroScript content scripts send, and serves the HTTP endpoint the Mobile Studio
 * plugin long-polls on 127.0.0.1:17614 (same protocol as mobile_mcp.py).
 */
public final class Hub {
    public static final int PORT = 17614;
    private static final long ALIVE_MS = 15000;
    private static final long POLL_HOLD_MS = 8000;

    private static boolean started = false;
    private static Context app;
    private static String token = "";
    private static JSONArray tools = new JSONArray();
    private static String pluginTemplate = "";

    private static final LinkedBlockingQueue<JSONObject> jobs = new LinkedBlockingQueue<>();
    private static final Map<String, LinkedBlockingQueue<JSONObject>> waiting = new ConcurrentHashMap<>();
    private static volatile long lastPoll = 0;
    private static volatile String place = "";
    private static final Map<String, Long> pending = new ConcurrentHashMap<>();
    private static final Set<String> accepted = ConcurrentHashMap.newKeySet();
    private static final long PAIR_TTL_MS = 6 * 60 * 1000L;
    private static long seq = 0;

    private Hub() {}

    public static synchronized void start(Context ctx) {
        if (started) return;
        started = true;
        app = ctx.getApplicationContext();
        try {
            tools = new JSONArray(readAsset("zs/tools.json"));
            pluginTemplate = readAsset("zs/plugin.template.lua");
        } catch (Exception e) {
            e.printStackTrace();
        }
        SharedPreferences sp = app.getSharedPreferences("zs", Context.MODE_PRIVATE);
        token = sp.getString("token", "");
        if (token.isEmpty()) {
            byte[] b = new byte[9];
            new SecureRandom().nextBytes(b);
            StringBuilder sb = new StringBuilder();
            for (byte x : b) sb.append(String.format("%02x", x));
            token = sb.toString();
            sp.edit().putString("token", token).apply();
        }
        Thread t = new Thread(Hub::serve, "zs-http");
        t.setDaemon(true);
        t.start();
    }

    private static String readAsset(String path) throws Exception {
        try (InputStream in = app.getAssets().open(path)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toString("UTF-8");
        }
    }

    public static String pluginSource() {
        return pluginTemplate;
    }

    public static boolean pluginAlive() {
        return System.currentTimeMillis() - lastPoll < ALIVE_MS;
    }

    public static String placeName() { return place; }

    /** True if a plugin is currently showing a pairing code and waiting for the user. */
    public static boolean waitingForCode() {
        long now = System.currentTimeMillis();
        for (Long t : pending.values()) if (now - t < PAIR_TTL_MS) return true;
        return false;
    }

    /** The user typed a code in the app: accept it if a plugin is really showing it. */
    public static boolean acceptCode(String code) {
        if (code == null) return false;
        code = code.trim();
        Long t = pending.get(code);
        if (t == null || System.currentTimeMillis() - t > PAIR_TTL_MS) return false;
        accepted.add(code);
        return true;
    }

    private static String pairReply(String code) {
        try {
            JSONObject r = new JSONObject();
            if (code == null || !code.matches("\\d{6}")) { r.put("token", JSONObject.NULL); return r.toString(); }
            long now = System.currentTimeMillis();
            for (Map.Entry<String, Long> e : pending.entrySet()) if (now - e.getValue() > PAIR_TTL_MS) pending.remove(e.getKey());
            if (pending.size() < 20) pending.putIfAbsent(code, now);
            if (accepted.remove(code)) {
                pending.remove(code);
                r.put("token", token);
            } else {
                r.put("token", JSONObject.NULL);
            }
            return r.toString();
        } catch (Exception e) {
            return "{\"token\":null}";
        }
    }

    // ───────── messages from the web pages (what background.js used to answer) ─────────
    public static JSONObject status() {
        JSONObject o = new JSONObject();
        try {
            boolean alive = pluginAlive();
            o.put("type", "zs-status");
            o.put("connected", true);
            o.put("mcpAlive", true);
            o.put("studio", alive);
            o.put("studioApp", alive);
            o.put("studioProc", JSONObject.NULL);
            o.put("tools", tools.length());
            JSONArray servers = new JSONArray();
            JSONObject s = new JSONObject();
            s.put("id", "roblox");
            s.put("alive", true);
            s.put("tools", tools.length());
            servers.put(s);
            o.put("servers", servers);
        } catch (Exception ignored) {}
        return o;
    }

    public static JSONObject handle(JSONObject msg) {
        JSONObject r = new JSONObject();
        try {
            String type = msg.optString("type");
            switch (type) {
                case "status":
                    return status();
                case "list_tools":
                    r.put("ok", true);
                    r.put("tools", tools);
                    return r;
                case "call_tool": {
                    String name = msg.optString("name");
                    int slash = name.lastIndexOf('/');
                    if (slash >= 0) name = name.substring(slash + 1);
                    JSONObject args = msg.optJSONObject("arguments");
                    long timeout = msg.optLong("timeout", 120000L);
                    return callTool(name, args == null ? new JSONObject() : args, timeout);
                }
                case "restart_mcp":
                    r.put("ok", true);
                    r.put("alive", true);
                    r.put("tools", tools);
                    r.put("servers", status().optJSONArray("servers"));
                    return r;
                case "reconnect":
                    r.put("ok", true);
                    return r;
                default:
                    r.put("ok", false);
                    r.put("error", "No disponible en la app movil: " + type);
                    return r;
            }
        } catch (Exception e) {
            try {
                r.put("ok", false);
                r.put("error", String.valueOf(e));
            } catch (Exception ignored) {}
            return r;
        }
    }

    private static JSONObject fail(String kind, String err) {
        JSONObject r = new JSONObject();
        try {
            r.put("ok", false);
            r.put("kind", kind);
            r.put("error", err);
        } catch (Exception ignored) {}
        return r;
    }

    private static JSONObject ok(String text) {
        JSONObject r = new JSONObject();
        try {
            r.put("ok", true);
            r.put("text", text);
            r.put("images", new JSONArray());
        } catch (Exception ignored) {}
        return r;
    }

    private static JSONObject callTool(String name, JSONObject args, long timeoutMs) {
        boolean alive = pluginAlive();
        if (name.equals("list_roblox_studios")) {
            return ok(alive ? "{\"studios\":[{\"id\":\"mobile-studio\",\"active\":true}]}" : "{\"studios\":[]}");
        }
        if (!alive) {
            return fail("disconnected",
                    "El plugin ZeroScript de Mobile Studio no esta conectado. Abre Mobile Studio, abre un place "
                            + "y comprueba que el plugin esta instalado.");
        }
        String id;
        synchronized (Hub.class) { id = "j" + (++seq); }
        LinkedBlockingQueue<JSONObject> slot = new LinkedBlockingQueue<>(1);
        waiting.put(id, slot);
        try {
            JSONObject job = new JSONObject();
            job.put("id", id);
            job.put("op", name);
            job.put("args", args);
            jobs.put(job);
            JSONObject res = slot.poll(Math.min(timeoutMs, 110000L), TimeUnit.MILLISECONDS);
            if (res == null) return fail("timeout", "Mobile Studio no respondio a '" + name + "' a tiempo.");
            if (res.optBoolean("ok")) return ok(res.optString("text"));
            return fail("error", res.optString("error", "error desconocido"));
        } catch (Exception e) {
            return fail("error", String.valueOf(e));
        } finally {
            waiting.remove(id);
        }
    }

    // ───────── HTTP server for the plugin ─────────
    private static void serve() {
        try (ServerSocket ss = new ServerSocket(PORT, 20, InetAddress.getByName("127.0.0.1"))) {
            while (true) {
                final Socket s = ss.accept();
                Thread t = new Thread(() -> client(s), "zs-conn");
                t.setDaemon(true);
                t.start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static String readLine(InputStream in) throws Exception {
        StringBuilder sb = new StringBuilder();
        int c;
        while ((c = in.read()) != -1) {
            if (c == '\n') break;
            if (c != '\r') sb.append((char) c);
            if (sb.length() > 16384) break;
        }
        if (c == -1 && sb.length() == 0) return null;
        return sb.toString();
    }

    private static Map<String, String> query(String q) {
        Map<String, String> m = new HashMap<>();
        if (q == null) return m;
        for (String p : q.split("&")) {
            int i = p.indexOf('=');
            try {
                if (i < 0) m.put(URLDecoder.decode(p, "UTF-8"), "");
                else m.put(URLDecoder.decode(p.substring(0, i), "UTF-8"),
                        URLDecoder.decode(p.substring(i + 1), "UTF-8"));
            } catch (Exception ignored) {}
        }
        return m;
    }

    private static void client(Socket s) {
        try (Socket sock = s) {
            sock.setSoTimeout(30000);
            InputStream in = new BufferedInputStream(sock.getInputStream());
            OutputStream out = sock.getOutputStream();
            String line = readLine(in);
            if (line == null) return;
            String[] parts = line.split(" ");
            if (parts.length < 2) return;
            String method = parts[0];
            String target = parts[1];
            int contentLength = 0;
            String h;
            while ((h = readLine(in)) != null && !h.isEmpty()) {
                int i = h.indexOf(':');
                if (i > 0 && h.substring(0, i).trim().equalsIgnoreCase("content-length")) {
                    try { contentLength = Integer.parseInt(h.substring(i + 1).trim()); } catch (Exception ignored) {}
                }
            }
            byte[] body = new byte[Math.min(contentLength, 8 * 1024 * 1024)];
            int off = 0;
            while (off < body.length) {
                int n = in.read(body, off, body.length - off);
                if (n < 0) break;
                off += n;
            }
            String path = target;
            String qs = null;
            int qi = target.indexOf('?');
            if (qi >= 0) { path = target.substring(0, qi); qs = target.substring(qi + 1); }
            Map<String, String> q = query(qs);

            if (method.equals("GET") && path.equals("/pair")) {
                reply(out, 200, pairReply(q.get("code")), "application/json");
                return;
            }
            String given = q.containsKey("token") ? q.get("token") : "";
            boolean authed = MessageDigest.isEqual(given.getBytes(StandardCharsets.UTF_8),
                    token.getBytes(StandardCharsets.UTF_8));
            if (!authed) { reply(out, 401, "{\"error\":\"bad token\"}", "application/json"); return; }

            if (method.equals("GET") && path.equals("/poll")) {
                lastPoll = System.currentTimeMillis();
                String info = q.get("info");
                if (info != null && !info.isEmpty()) {
                    try { place = new JSONObject(info).optString("place", ""); } catch (Exception ignored) {}
                }
                JSONObject job = jobs.poll(POLL_HOLD_MS, TimeUnit.MILLISECONDS);
                lastPoll = System.currentTimeMillis();
                JSONObject resp = new JSONObject();
                resp.put("job", job == null ? JSONObject.NULL : job);
                reply(out, 200, resp.toString(), "application/json");
            } else if (method.equals("POST") && path.equals("/result")) {
                JSONObject msg = new JSONObject(new String(body, 0, off, StandardCharsets.UTF_8));
                lastPoll = System.currentTimeMillis();
                LinkedBlockingQueue<JSONObject> slot = waiting.get(msg.optString("id"));
                if (slot != null) slot.offer(msg);
                reply(out, 200, "{\"ok\":true}", "application/json");
            } else if (method.equals("GET") && path.equals("/plugin.lua")) {
                reply(out, 200, pluginSource(), "text/plain");
            } else {
                reply(out, 404, "{\"error\":\"not found\"}", "application/json");
            }
        } catch (Exception ignored) {
        }
    }

    private static void reply(OutputStream out, int code, String body, String ctype) throws Exception {
        byte[] b = body.getBytes(StandardCharsets.UTF_8);
        String head = "HTTP/1.1 " + code + (code == 200 ? " OK" : " Error") + "\r\n"
                + "Content-Type: " + ctype + "; charset=utf-8\r\n"
                + "Content-Length: " + b.length + "\r\n"
                + "Cache-Control: no-store\r\n"
                + "Connection: close\r\n\r\n";
        out.write(head.getBytes(StandardCharsets.ISO_8859_1));
        out.write(b);
        out.flush();
    }
}

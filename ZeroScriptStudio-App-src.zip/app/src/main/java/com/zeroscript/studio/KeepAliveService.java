package com.zeroscript.studio;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.IBinder;

/** Keeps the process (and the local plugin server) alive while you work in Mobile Studio. */
public class KeepAliveService extends Service {
    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("zs", "ZeroScript", NotificationManager.IMPORTANCE_LOW));
        Notification n = new Notification.Builder(this, "zs")
                .setContentTitle("ZeroScript Studio")
                .setContentText("Servidor local activo para Mobile Studio")
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .setOngoing(true)
                .build();
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        Hub.start(this);
        return START_STICKY;
    }
}

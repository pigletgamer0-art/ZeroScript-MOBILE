package com.zeroscript.studio;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.text.InputType;
import android.widget.EditText;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.JavaScriptReplyProxy;
import androidx.webkit.WebMessageCompat;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    /** One AI chat site: label, start URL, hosts/origins, provider script, optional MAIN-world scripts. */
    static final class Provider {
        final String id, label, url, script;
        final String[] origins;
        final String[] earlyScripts;
        Provider(String id, String label, String url, String script, String[] origins, String... early) {
            this.id = id; this.label = label; this.url = url; this.script = script;
            this.origins = origins; this.earlyScripts = early;
        }
    }

    static final Provider[] PROVIDERS = new Provider[]{
            new Provider("deepseek", "DeepSeek", "https://chat.deepseek.com", "deepseek.js",
                    new String[]{"https://chat.deepseek.com"}),
            new Provider("chatgpt", "ChatGPT", "https://chatgpt.com", "chatgpt.js",
                    new String[]{"https://chatgpt.com", "https://chat.openai.com"}, "chatgpt-cm.js"),
            new Provider("gemini", "Gemini", "https://gemini.google.com", "gemini.js",
                    new String[]{"https://gemini.google.com"}),
            new Provider("kimi", "Kimi", "https://www.kimi.ai", "kimi.js",
                    new String[]{"https://www.kimi.ai", "https://kimi.ai"}),
            new Provider("glm", "GLM", "https://chat.z.ai", "glm.js",
                    new String[]{"https://chat.z.ai"}),
            new Provider("qwen", "Qwen", "https://chat.qwen.ai", "qwen.js",
                    new String[]{"https://chat.qwen.ai"}, "qwen-net.js"),
            new Provider("arena", "Arena", "https://arena.ai", "arena.js",
                    new String[]{"https://arena.ai"}),
            new Provider("meta", "Meta AI", "https://www.meta.ai", "meta.js",
                    new String[]{"https://www.meta.ai", "https://meta.ai"}),
    };

    private final Map<String, WebView> views = new HashMap<>();
    private final Map<String, JavaScriptReplyProxy> proxies = new HashMap<>();
    private final Map<String, String> scriptCache = new HashMap<>();
    private final ExecutorService pool = Executors.newCachedThreadPool();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private FrameLayout container;
    private TextView statusView;
    private Provider current;
    private String shimJs = "";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        Hub.start(this);
        try { startForegroundService(new Intent(this, KeepAliveService.class)); } catch (Exception ignored) {}
        try { shimJs = asset("zs/shim.js"); } catch (Exception e) { shimJs = ""; }

        if (!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            Toast.makeText(this, "Actualiza 'Android System WebView' en Play Store para usar ZeroScript.",
                    Toast.LENGTH_LONG).show();
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        for (final Provider p : PROVIDERS) {
            Button btn = new Button(this);
            btn.setText(p.label);
            btn.setAllCaps(false);
            btn.setOnClickListener(v -> show(p));
            chips.addView(btn);
        }
        scroll.addView(chips);
        top.addView(scroll, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button menu = new Button(this);
        menu.setText("⋮");
        menu.setOnClickListener(this::openMenu);
        top.addView(menu);
        root.addView(top);

        statusView = new TextView(this);
        statusView.setPadding(24, 8, 24, 8);
        statusView.setGravity(Gravity.CENTER_VERTICAL);
        statusView.setTextSize(13);
        root.addView(statusView);

        container = new FrameLayout(this);
        root.addView(container, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        show(PROVIDERS[0]);
        tick();
    }

    private void tick() {
        boolean alive = Hub.pluginAlive();
        String place = Hub.placeName();
        statusView.setText(alive
                ? "Mobile Studio: conectado" + (place.isEmpty() ? "" : " (" + place + ")")
                : (Hub.waitingForCode()
                    ? "Mobile Studio muestra un codigo: menu \u22EE > Conectar Mobile Studio y escribelo"
                    : "Mobile Studio: sin conexion - instala el plugin (menu \u22EE) y abre un place"));
        statusView.setTextColor(alive ? 0xFF1B8A3A : 0xFFB3261E);
        // push status to every page that has the shim
        final String push = pushJson();
        for (JavaScriptReplyProxy p : new HashSet<>(proxies.values())) {
            try { p.postMessage(push); } catch (Exception ignored) {}
        }
        ui.postDelayed(this::tick, 2000);
    }

    private String pushJson() {
        try {
            JSONObject o = new JSONObject();
            o.put("t", "push");
            o.put("data", Hub.status());
            return o.toString();
        } catch (Exception e) { return "{}"; }
    }

    private void openMenu(View anchor) {
        PopupMenu m = new PopupMenu(this, anchor);
        m.getMenu().add(0, 5, 0, "Conectar Mobile Studio (codigo)");
        m.getMenu().add(0, 4, 0, "Enviar plugin a Mobile Studio (1 toque)");
        m.getMenu().add(0, 1, 1, "Guardar plugin en Descargas");
        m.getMenu().add(0, 2, 2, "Abrir Mobile Studio");
        m.getMenu().add(0, 3, 3, "Recargar pagina");
        m.setOnMenuItemClickListener(it -> {
            switch (it.getItemId()) {
                case 1: savePlugin(false); break;
                case 4: savePlugin(true); break;
                case 5: askCode(); break;
                case 2: openStudio(); break;
                case 3: if (current != null && views.get(current.id) != null) views.get(current.id).reload(); break;
            }
            return true;
        });
        m.show();
    }

    private void askCode() {
        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER);
        et.setHint("Codigo de 6 digitos");
        new AlertDialog.Builder(this)
                .setTitle("Conectar Mobile Studio")
                .setMessage("En Mobile Studio, con el plugin ZeroScript instalado y un place abierto, aparece un codigo de 6 digitos. Escribelo aqui.")
                .setView(et)
                .setPositiveButton("Conectar", (d, w) -> {
                    boolean ok = Hub.acceptCode(et.getText().toString());
                    Toast.makeText(this, ok ? "Codigo aceptado: conectando..."
                            : "Ese codigo no esta activo. Revisa que el plugin lo muestre y escribelo de nuevo.",
                            Toast.LENGTH_LONG).show();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void savePlugin(boolean send) {
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Downloads.DISPLAY_NAME, "ZeroScriptMobile.lua");
            v.put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream");
            v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            try (OutputStream o = getContentResolver().openOutputStream(u)) {
                o.write(Hub.pluginSource().getBytes(StandardCharsets.UTF_8));
            }
            if (send) {
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setDataAndType(u, "application/octet-stream");
                i.setPackage("com.exampletest.mobilestudiotest");
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                try {
                    startActivity(i);
                    Toast.makeText(this, "Enviado. Si Mobile Studio lo abre como modelo en vez de plugin, usa Plugins > Install Plugin from File (esta en Descargas).",
                            Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Mobile Studio no lo acepto. Guardado en Descargas: usa Plugins > Install Plugin from File.",
                            Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(this, "Guardado en Descargas: ZeroScriptMobile.lua. En Mobile Studio: Plugins > Install Plugin from File.",
                        Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo guardar: " + e, Toast.LENGTH_LONG).show();
        }
    }

    private void openStudio() {
        Intent i = getPackageManager().getLaunchIntentForPackage("com.exampletest.mobilestudiotest");
        if (i == null) {
            Toast.makeText(this, "No encuentro Mobile Studio instalado.", Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(this, "Consejo: usa pantalla dividida para ver las dos apps a la vez.", Toast.LENGTH_LONG).show();
        startActivity(i);
    }

    // ───────── web views ─────────
    private void show(Provider p) {
        current = p;
        WebView w = views.get(p.id);
        if (w == null) {
            w = create(p);
            views.put(p.id, w);
            container.addView(w, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            w.loadUrl(p.url);
        }
        for (Map.Entry<String, WebView> e : views.entrySet()) {
            e.getValue().setVisibility(e.getKey().equals(p.id) ? View.VISIBLE : View.GONE);
        }
    }

    private WebView create(final Provider p) {
        final WebView w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUserAgentString(s.getUserAgentString().replace("; wv", ""));
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(w, true);

        final Set<String> origins = new HashSet<>();
        for (String o : p.origins) origins.add(o);

        if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            WebViewCompat.addWebMessageListener(w, "ZSNative", origins,
                    (view, message, sourceOrigin, isMainFrame, replyProxy) -> {
                        if (!isMainFrame) return;   // never answer iframes
                        proxies.put(p.id, replyProxy);
                        final String data = message.getData();
                        pool.execute(() -> answer(data, replyProxy));
                    });
        }
        String early = shimJs;
        for (String f : p.earlyScripts) {
            try { early += "\n;\n" + asset("zs/providers/" + f); } catch (Exception ignored) {}
        }
        final boolean docStart = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT);
        final String earlyFinal = early;
        if (docStart) {
            WebViewCompat.addDocumentStartJavaScript(w, earlyFinal, origins);
        }
        w.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView v, String url, android.graphics.Bitmap f) {
                if (!docStart && isOwn(url, p)) v.evaluateJavascript(earlyFinal, null);
            }
            @Override public void onPageFinished(WebView v, String url) {
                if (isOwn(url, p)) v.evaluateJavascript(mainScript(p), null);
            }
        });
        return w;
    }

    private static boolean isOwn(String url, Provider p) {
        if (url == null) return false;
        for (String o : p.origins) if (url.startsWith(o)) return true;
        return false;
    }

    private void answer(String data, final JavaScriptReplyProxy proxy) {
        String out;
        try {
            JSONObject req = new JSONObject(data);
            JSONObject resp = Hub.handle(req.getJSONObject("msg"));
            JSONObject o = new JSONObject();
            o.put("t", "resp");
            o.put("id", req.getString("id"));
            o.put("data", resp);
            out = o.toString();
        } catch (Exception e) {
            return;
        }
        final String fin = out;
        ui.post(() -> { try { proxy.postMessage(fin); } catch (Exception ignored) {} });
    }

    private String mainScript(Provider p) {
        String cached = scriptCache.get(p.id);
        if (cached != null) return cached;
        try {
            StringBuilder sb = new StringBuilder();
            sb.append("(function(){if(window.__zsInjected)return;window.__zsInjected=true;");
            sb.append("var st=document.createElement('style');st.textContent=")
              .append(JSONObject.quote(asset("zs/overlay.css")))
              .append(";(document.head||document.documentElement).appendChild(st);\n");
            sb.append(asset("zs/config.js")).append("\n;\n");
            sb.append(asset("zs/parser.js")).append("\n;\n");
            sb.append(asset("zs/providers/" + p.script)).append("\n;\n");
            sb.append(asset("zs/main.js")).append("\n;\n");
            sb.append("})();");
            cached = sb.toString();
            scriptCache.put(p.id, cached);
            return cached;
        } catch (Exception e) {
            return "console.error('ZeroScript: no se pudo cargar los scripts')";
        }
    }

    private String asset(String path) throws Exception {
        try (InputStream in = getAssets().open(path)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toString("UTF-8");
        }
    }

    @Override
    public void onBackPressed() {
        WebView w = current == null ? null : views.get(current.id);
        if (w != null && w.canGoBack()) w.goBack();
        else super.onBackPressed();
    }
}

-- ZeroScript Mobile - plugin for the "Mobile Studio" Android app.
-- Connects the app to the ZeroScript bridge running on your PC (or in Termux),
-- so the AI chat in your browser can read/edit scripts and run Lua in the place
-- you have open on the phone.
--
-- Plain Lua 5.2 syntax on purpose (the app runs a Lua 5.2 interpreter).
-- URL and token below are filled in automatically when you download this file
-- from the bridge (http://<bridge-ip>:17614/plugin.lua?token=<token>).

local BRIDGE_URL = "http://127.0.0.1:17614"
local TOKEN      = ""   -- se obtiene al emparejar con la app ZeroScript Studio
pcall(function() TOKEN = plugin:GetSetting("zs_token") or "" end)

local MAX_TEXT = 60000      -- max characters sent back per tool call
local LOG_MAX  = 400        -- console lines kept

local HttpService = game:GetService("HttpService")
pcall(function() HttpService.HttpEnabled = true end)

local sleep = (task and task.wait) or wait
local G = (getfenv and getfenv(0)) or _G

-- ───────────── console capture ─────────────
local logbuf = {}
local function addlog(line)
  logbuf[#logbuf + 1] = tostring(line)
  if #logbuf > LOG_MAX then table.remove(logbuf, 1) end
end
pcall(function()
  local LogService = game:GetService("LogService")
  LogService.MessageOut:Connect(function(msg, kind)
    addlog("[" .. tostring(kind) .. "] " .. tostring(msg))
  end)
end)

-- ───────────── helpers ─────────────
local function trunc(s)
  s = tostring(s)
  if #s > MAX_TEXT then
    return s:sub(1, MAX_TEXT) .. "\n...[truncated, " .. (#s - MAX_TEXT) .. " more chars]"
  end
  return s
end

local function urlenc(s)
  return (tostring(s):gsub("[^%w%-_%.~]", function(c)
    return string.format("%%%02X", string.byte(c))
  end))
end

local function split(s, sep)
  local out = {}
  for part in string.gmatch(s, "[^" .. sep .. "]+") do out[#out + 1] = part end
  return out
end

-- "game.Workspace.Folder.Part" (or with "/" separators) -> Instance, err
local function resolve(path)
  path = tostring(path or "game")
  path = path:gsub("/", ".")
  local parts = split(path, ".")
  local cur = game
  local start = 1
  if parts[1] == "game" then start = 2 end
  if parts[1] == "workspace" or parts[1] == "Workspace" then
    cur = workspace; start = 2
  end
  for i = start, #parts do
    local name = parts[i]
    local nxt = cur:FindFirstChild(name)
    if not nxt and cur == game then
      local ok, svc = pcall(function() return game:GetService(name) end)
      if ok then nxt = svc end
    end
    if not nxt then
      return nil, "No instance named '" .. name .. "' under " .. tostring(cur:GetFullName()) ..
                  " (while resolving '" .. path .. "')"
    end
    cur = nxt
  end
  return cur
end

local function isScript(inst)
  local ok, r = pcall(function()
    return inst:IsA("LuaSourceContainer")
  end)
  if ok and r then return true end
  local c = inst.ClassName
  return c == "Script" or c == "LocalScript" or c == "ModuleScript"
end

local function getSource(inst) return inst.Source end

-- ───────────── tools ─────────────
local tools = {}

tools.get_studio_state = function()
  local out = {}
  local place = "?"
  pcall(function() place = game.Name end)
  out[#out + 1] = "Place: " .. tostring(place)
  pcall(function() out[#out + 1] = "PlaceId: " .. tostring(game.PlaceId) end)
  pcall(function()
    local sel = game:GetService("Selection"):Get()
    local names = {}
    for i, s in ipairs(sel) do names[#names + 1] = s:GetFullName() end
    out[#out + 1] = "Selection (" .. #sel .. "): " .. table.concat(names, ", ")
  end)
  pcall(function()
    out[#out + 1] = "Running (play mode): " .. tostring(game:GetService("RunService"):IsRunning())
  end)
  out[#out + 1] = "Available DataModels: game (Edit)"
  out[#out + 1] = "Platform: Mobile Studio (Android)"
  return table.concat(out, "\n")
end

tools.execute_luau = function(args)
  local code = args.code
  if type(code) ~= "string" then error("'code' (string) is required") end
  local lines = {}
  local env = setmetatable({
    print = function(...)
      local t = {}
      for i = 1, select("#", ...) do t[#t + 1] = tostring((select(i, ...))) end
      lines[#lines + 1] = table.concat(t, "\t")
      addlog(lines[#lines])
    end,
    warn = function(...)
      local t = {}
      for i = 1, select("#", ...) do t[#t + 1] = tostring((select(i, ...))) end
      lines[#lines + 1] = "[warn] " .. table.concat(t, "\t")
      addlog(lines[#lines])
    end,
    plugin = plugin,
  }, { __index = G, __newindex = G })

  local fn, err
  if load and pcall(load, "return 1", "t", "t", {}) then
    fn, err = load(code, "=execute_luau", "t", env)
  end
  if not fn then
    local f2, e2 = (loadstring or load)(code, "=execute_luau")
    fn, err = f2, e2 or err
    if fn and setfenv then pcall(setfenv, fn, env) end
  end
  if not fn then error("Syntax error: " .. tostring(err)) end

  local res = { pcall(fn) }
  local ok = table.remove(res, 1)
  local out = {}
  if #lines > 0 then out[#out + 1] = table.concat(lines, "\n") end
  if not ok then
    out[#out + 1] = "Runtime error: " .. tostring(res[1])
    error(table.concat(out, "\n"))
  end
  if #res > 0 then
    local t = {}
    for i = 1, #res do t[#t + 1] = tostring(res[i]) end
    out[#out + 1] = "Returned: " .. table.concat(t, ", ")
  end
  if #out == 0 then out[1] = "(ok, no output)" end
  return table.concat(out, "\n")
end

tools.search_game_tree = function(args)
  local root, err = resolve(args.path or "game")
  if not root then error(err) end
  local maxDepth = tonumber(args.max_depth) or 2
  local limit = tonumber(args.limit) or 300
  local fclass = args.class_name and string.lower(args.class_name)
  local fname = args.name and string.lower(args.name)
  local filtering = (fclass ~= nil) or (fname ~= nil)
  local out, count = {}, 0
  local function matches(inst)
    if fclass and not string.find(string.lower(inst.ClassName), fclass, 1, true) then return false end
    if fname and not string.find(string.lower(inst.Name), fname, 1, true) then return false end
    return true
  end
  local function walk(inst, depth)
    if count >= limit then return end
    local kids = inst:GetChildren()
    for i, c in ipairs(kids) do
      if count >= limit then return end
      if (not filtering) or matches(c) then
        count = count + 1
        out[#out + 1] = string.rep("  ", filtering and 0 or depth) ..
          c.Name .. " [" .. c.ClassName .. "]" .. (filtering and ("  " .. c:GetFullName()) or "")
      end
      if depth + 1 < maxDepth then walk(c, depth + 1) end
    end
  end
  walk(root, 0)
  local head = root:GetFullName() .. " [" .. root.ClassName .. "]"
  if count >= limit then out[#out + 1] = "...(limit " .. limit .. " reached)" end
  return head .. "\n" .. table.concat(out, "\n")
end

local COMMON_PROPS = {
  "Name", "ClassName", "Parent", "Position", "Size", "CFrame", "Orientation", "Color",
  "BrickColor", "Material", "Transparency", "Anchored", "CanCollide", "Shape", "Text",
  "Visible", "Enabled", "Value", "Disabled", "RunContext", "Volume", "Brightness",
  "Range", "MeshId", "TextureID", "Image", "PrimaryPart", "Health", "WalkSpeed",
}

tools.inspect_instance = function(args)
  local inst, err = resolve(args.path)
  if not inst then error(err) end
  local out = {}
  out[#out + 1] = inst:GetFullName() .. " [" .. inst.ClassName .. "]"
  for i, p in ipairs(COMMON_PROPS) do
    local ok, v = pcall(function() return inst[p] end)
    if ok and v ~= nil and type(v) ~= "function" then
      if p ~= "Name" and p ~= "ClassName" then
        out[#out + 1] = "  " .. p .. " = " .. tostring(v)
      end
    end
  end
  pcall(function()
    local attrs = inst:GetAttributes()
    for k, v in pairs(attrs) do out[#out + 1] = "  @" .. tostring(k) .. " = " .. tostring(v) end
  end)
  local kids = inst:GetChildren()
  out[#out + 1] = "Children (" .. #kids .. "):"
  for i = 1, math.min(#kids, 60) do
    out[#out + 1] = "  " .. kids[i].Name .. " [" .. kids[i].ClassName .. "]"
  end
  if #kids > 60 then out[#out + 1] = "  ...(" .. (#kids - 60) .. " more)" end
  if isScript(inst) then
    local src = getSource(inst) or ""
    local _, nl = src:gsub("\n", "\n")
    out[#out + 1] = "Script source: " .. (nl + 1) .. " lines, " .. #src .. " chars"
  end
  return table.concat(out, "\n")
end

tools.script_read = function(args)
  local inst, err = resolve(args.path)
  if not inst then error(err) end
  if not isScript(inst) then error(inst:GetFullName() .. " is a " .. inst.ClassName .. ", not a script") end
  local src = getSource(inst) or ""
  local out, n = {}, 0
  local s = tonumber(args.start_line) or 1
  local e = tonumber(args.end_line) or math.huge
  for line in (src .. "\n"):gmatch("(.-)\n") do
    n = n + 1
    if n >= s and n <= e then out[#out + 1] = n .. "\t" .. line end
  end
  return inst:GetFullName() .. " [" .. inst.ClassName .. "] lines " .. s .. "-" ..
         (e == math.huge and n or math.min(e, n)) .. " of " .. n .. "\n" .. table.concat(out, "\n")
end

tools.script_grep = function(args)
  local pat = args.pattern
  if type(pat) ~= "string" or pat == "" then error("'pattern' is required") end
  local root, err = resolve(args.path or "game")
  if not root then error(err) end
  local cs = args.case_sensitive
  local needle = cs and pat or string.lower(pat)
  local out, hits = {}, 0
  local function scan(inst)
    if hits >= 200 then return end
    if isScript(inst) then
      local okS, src = pcall(getSource, inst)
      if okS and type(src) == "string" then
        local n = 0
        for line in (src .. "\n"):gmatch("(.-)\n") do
          n = n + 1
          local hay = cs and line or string.lower(line)
          if string.find(hay, needle, 1, true) then
            hits = hits + 1
            out[#out + 1] = inst:GetFullName() .. ":" .. n .. ": " .. line
            if hits >= 200 then return end
          end
        end
      end
    end
    for i, c in ipairs(inst:GetChildren()) do scan(c) end
  end
  scan(root)
  if hits == 0 then return "No matches for '" .. pat .. "'." end
  return table.concat(out, "\n") .. (hits >= 200 and "\n...(200 match limit)" or "")
end

local function plainCount(s, sub)
  local c, i = 0, 1
  while true do
    local a, b = string.find(s, sub, i, true)
    if not a then return c end
    c = c + 1; i = b + 1
  end
end

local function plainReplace(s, old, new)
  local out, i = {}, 1
  while true do
    local a, b = string.find(s, old, i, true)
    if not a then out[#out + 1] = s:sub(i); break end
    out[#out + 1] = s:sub(i, a - 1)
    out[#out + 1] = new
    i = b + 1
  end
  return table.concat(out)
end

tools.multi_edit = function(args)
  local edits = args.edits
  if type(edits) ~= "table" or #edits == 0 then error("'edits' (non-empty list) is required") end
  -- validate everything first so a bad edit never leaves half the work applied
  local plan, report = {}, {}
  for i, ed in ipairs(edits) do
    local inst, err = resolve(ed.path)
    if not inst then error("edit #" .. i .. ": " .. err) end
    if not isScript(inst) then error("edit #" .. i .. ": " .. inst:GetFullName() .. " is not a script") end
    local src = plan[inst] and plan[inst].src or (getSource(inst) or "")
    if ed.new_source ~= nil then
      src = tostring(ed.new_source)
    else
      local old, new = ed.old_string, ed.new_string
      if type(old) ~= "string" or type(new) ~= "string" or old == "" then
        error("edit #" .. i .. ": needs old_string and new_string (or new_source)")
      end
      local c = plainCount(src, old)
      if c == 0 then error("edit #" .. i .. ": old_string not found in " .. inst:GetFullName()) end
      if c > 1 and not ed.replace_all then
        error("edit #" .. i .. ": old_string matches " .. c .. " times in " .. inst:GetFullName() ..
              " - add more context or set replace_all")
      end
      src = plainReplace(src, old, new)
    end
    plan[inst] = { src = src }
    report[#report + 1] = "edit #" .. i .. " ok: " .. inst:GetFullName()
  end
  pcall(function() game:GetService("ChangeHistoryService"):SetWaypoint("ZeroScript edit") end)
  for inst, p in pairs(plan) do inst.Source = p.src end
  pcall(function() game:GetService("ChangeHistoryService"):SetWaypoint("ZeroScript edit done") end)
  return table.concat(report, "\n")
end

tools.get_console_output = function(args)
  local limit = tonumber(args.limit) or 100
  local from = math.max(1, #logbuf - limit + 1)
  local out = {}
  for i = from, #logbuf do out[#out + 1] = logbuf[i] end
  if #out == 0 then return "(console is empty)" end
  return table.concat(out, "\n")
end

-- ───────────── transport ─────────────
local running = true
local connected = false

local function http(method, path, body)
  local url = BRIDGE_URL .. path
  if HttpService.RequestAsync then
    local r = HttpService:RequestAsync({
      Url = url, Method = method, Body = body,
      Headers = body and { ["Content-Type"] = "application/json" } or nil,
    })
    if r.Success == false then error("HTTP " .. tostring(r.StatusCode)) end
    return r.Body
  end
  if method == "GET" then return HttpService:GetAsync(url) end
  return HttpService:PostAsync(url, body, Enum.HttpContentType.ApplicationJson)
end

local function sendResult(id, ok, text)
  local payload = HttpService:JSONEncode({ id = id, ok = ok, text = ok and trunc(text) or nil,
                                           error = (not ok) and trunc(text) or nil })
  local okH, err = pcall(http, "POST", "/result?token=" .. urlenc(TOKEN), payload)
  if not okH then addlog("[zeroscript] could not send result: " .. tostring(err)) end
end

local function handleJob(job)
  local fn = tools[job.op]
  if not fn then return sendResult(job.id, false, "unknown op '" .. tostring(job.op) .. "'") end
  local ok, res = pcall(fn, job.args or {})
  if ok then sendResult(job.id, true, res) else sendResult(job.id, false, tostring(res)) end
end

local function spawnFn(f)
  if task and task.spawn then return task.spawn(f) end
  if spawn then return spawn(f) end
  return f()
end


-- ───────────── emparejamiento con la app ─────────────
local function showCode(code)
  local text = "ZeroScript\nCodigo: " .. code .. "\n\nAbre la app ZeroScript Studio,\nmenu \226\139\174 > Conectar Mobile Studio\ny escribe este codigo."
  local updated = false
  pcall(function()
    local g
    if plugin and plugin.CreateDockWidgetPluginGui then
      local info = DockWidgetPluginGuiInfo.new(Enum.InitialDockState.Float, true, false, 300, 200, 220, 160)
      g = plugin:CreateDockWidgetPluginGui("ZeroScriptPair", info)
      g.Title = "ZeroScript - conectar"
    end
    local holder = g
    if not holder then
      local sg = Instance.new("ScreenGui")
      sg.Name = "ZeroScriptPair"
      pcall(function() sg.Parent = game:GetService("CoreGui") end)
      if not sg.Parent then sg.Parent = game:GetService("StarterGui") end
      holder = sg
    end
    local l = Instance.new("TextLabel")
    l.Size = UDim2.new(1, 0, 1, 0)
    l.BackgroundColor3 = Color3.fromRGB(30, 30, 34)
    l.TextColor3 = Color3.fromRGB(255, 255, 255)
    l.TextSize = 18
    l.TextWrapped = true
    l.Text = text
    l.Parent = holder
    updated = true
  end)
  print("[ZeroScript] " .. text:gsub("\n", " | "))
end

local function hideCode()
  pcall(function()
    -- best effort: remove any pairing window we created
    for _, parent in ipairs({ game:GetService("CoreGui"), game:GetService("StarterGui") }) do
      local f = parent:FindFirstChild("ZeroScriptPair")
      if f then f:Destroy() end
    end
  end)
end

local function pair()
  while running do
    local seed = os.time() + math.floor((os.clock() or 0) * 1000)
    math.randomseed(seed)
    local code = string.format("%06d", math.random(0, 999999))
    showCode(code)
    for i = 1, 150 do          -- ~5 min por codigo
      if not running then return false end
      local ok, body = pcall(http, "GET", "/pair?code=" .. code)
      if ok then
        local okD, data = pcall(function() return HttpService:JSONDecode(body) end)
        if okD and data and data.token and data.token ~= "" then
          TOKEN = data.token
          pcall(function() plugin:SetSetting("zs_token", TOKEN) end)
          hideCode()
          print("[ZeroScript] emparejado con la app")
          return true
        end
      end
      sleep(2)
    end
  end
  return false
end

local function loop()
  local backoff = 1
  while running do
    if TOKEN == "" then
      if not pair() then return end
    end
    local place = "?"
    pcall(function() place = game.Name end)
    local info = HttpService:JSONEncode({ place = place })
    local ok, body = pcall(http, "GET", "/poll?token=" .. urlenc(TOKEN) .. "&info=" .. urlenc(info))
    if ok then
      if not connected then
        connected = true
        print("[ZeroScript] connected to bridge at " .. BRIDGE_URL)
      end
      backoff = 1
      local okD, data = pcall(function() return HttpService:JSONDecode(body) end)
      if okD and data and data.job then
        spawnFn(function() handleJob(data.job) end)
      end
    else
      if tostring(body):find("401", 1, true) then
        TOKEN = ""
        pcall(function() plugin:SetSetting("zs_token", "") end)
        connected = false
      end
      if connected then
        connected = false
        warn("[ZeroScript] lost connection to bridge: " .. tostring(body))
      elseif backoff == 1 then
        warn("[ZeroScript] cannot reach bridge at " .. BRIDGE_URL .. ": " .. tostring(body))
      end
      sleep(backoff)
      backoff = math.min(backoff * 2, 10)
    end
    sleep(0.05)
  end
end

-- optional toolbar button: toggles the connection
pcall(function()
  if plugin then
    local tb = plugin:CreateToolbar("ZeroScript")
    local btn = tb:CreateButton("ZeroScript", "Connect / disconnect the ZeroScript bridge", "")
    btn.Click:Connect(function()
      if running then
        running = false
        print("[ZeroScript] stopped (tap again to restart)")
      else
        running = true
        spawnFn(loop)
        print("[ZeroScript] restarting...")
      end
    end)
  end
end)

print("[ZeroScript] Mobile plugin started - bridge: " .. BRIDGE_URL)
spawnFn(loop)

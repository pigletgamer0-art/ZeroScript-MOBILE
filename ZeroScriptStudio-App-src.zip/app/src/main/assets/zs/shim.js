// chrome.* shim: lets the unmodified ZeroScript content scripts run inside an Android WebView.
(function () {
  if (window.__zsShim) return;
  var N = window.ZSNative;
  if (!N) return;
  window.__zsShim = true;
  var pend = {}, seq = 0, listeners = [];
  N.onmessage = function (e) {
    var m;
    try { m = JSON.parse(e.data); } catch (_) { return; }
    if (m.t === "resp") {
      var cb = pend[m.id];
      if (cb) { delete pend[m.id]; cb(m.data); }
    } else if (m.t === "push") {
      listeners.slice().forEach(function (fn) { try { fn(m.data, {}, function () {}); } catch (_) {} });
    }
  };
  var PFX = "zs:";
  function pick(keys) {
    var out = {};
    function one(k, def) {
      var v = null;
      try { v = localStorage.getItem(PFX + k); } catch (_) {}
      if (v !== null) { try { out[k] = JSON.parse(v); } catch (_) {} }
      else if (def !== undefined) out[k] = def;
    }
    if (keys === null || keys === undefined) {
      try {
        for (var i = 0; i < localStorage.length; i++) {
          var k = localStorage.key(i);
          if (k.indexOf(PFX) === 0) one(k.slice(PFX.length));
        }
      } catch (_) {}
    } else if (typeof keys === "string") one(keys);
    else if (Array.isArray(keys)) keys.forEach(function (k) { one(k); });
    else Object.keys(keys).forEach(function (k) { one(k, keys[k]); });
    return out;
  }
  function wrap(fn, cb) {
    if (typeof cb === "function") { try { cb(fn()); } catch (e) { console.error(e); } return undefined; }
    return Promise.resolve().then(fn);
  }
  var local = {
    get: function (keys, cb) { return wrap(function () { return pick(keys); }, cb); },
    set: function (obj, cb) {
      return wrap(function () {
        Object.keys(obj || {}).forEach(function (k) {
          try { localStorage.setItem(PFX + k, JSON.stringify(obj[k])); } catch (_) {}
        });
      }, cb);
    },
    remove: function (keys, cb) {
      return wrap(function () {
        [].concat(keys).forEach(function (k) { try { localStorage.removeItem(PFX + k); } catch (_) {} });
      }, cb);
    }
  };
  var c = window.chrome || {};
  c.runtime = {
    lastError: undefined,
    getManifest: function () { return { version: "1.5.5" }; },
    sendMessage: function (msg, cb) {
      return new Promise(function (resolve) {
        var id = String(++seq);
        pend[id] = function (d) {
          if (typeof cb === "function") { try { cb(d); } catch (e) { console.error(e); } }
          resolve(d);
        };
        try { N.postMessage(JSON.stringify({ id: id, msg: msg })); }
        catch (e) { delete pend[id]; resolve(undefined); }
      });
    },
    onMessage: {
      addListener: function (fn) { listeners.push(fn); },
      removeListener: function (fn) { listeners = listeners.filter(function (f) { return f !== fn; }); }
    }
  };
  c.storage = { local: local };
  window.chrome = c;
})();

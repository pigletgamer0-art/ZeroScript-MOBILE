# ZeroScript Studio (app Android)

App con las IAs (DeepSeek, ChatGPT, Gemini, Kimi, GLM, Qwen, Arena, Meta AI) en pestañas. Lleva ZeroScript integrado
y un servidor local que habla con el plugin de Mobile Studio. Sin PC, sin Termux, sin extension.

## Compilar el APK (una sola vez, gratis, sin instalar nada)
1. Crea una cuenta en github.com y un repositorio nuevo (privado esta bien).
2. Sube TODO el contenido de esta carpeta (incluida la carpeta oculta `.github`). Es mas facil desde un PC:
   "Add file > Upload files" y arrastra todo.
3. Pestaña **Actions** > "Build APK" > "Run workflow". Tarda ~5 min.
4. Abre la ejecucion terminada > **Artifacts** > descarga `ZeroScriptStudio-apk` (zip con `app-debug.apk`).
5. Instala el APK en el telefono (permite "instalar apps desconocidas").
Si la compilacion falla, copia el error del log y se corrige.

## Usar
1. Abre ZeroScript Studio. Menu ⋮ > **Enviar plugin a Mobile Studio** (si no lo instala solo: "Guardar plugin en Descargas" y
   luego, en Mobile Studio, Plugins > Install Plugin from File). Se instala una sola vez.
2. Abre un place en Mobile Studio: el plugin muestra un **codigo de 6 digitos** con instrucciones.
3. En ZeroScript Studio: menu ⋮ > **Conectar Mobile Studio (codigo)** y escribe el codigo. Listo: la barra se pone verde.
   (Se recuerda; la proxima vez conecta solo.)
4. Elige una IA, inicia sesion (correo/contraseña; "Continuar con Google" suele estar bloqueado en WebViews),
   abre un chat nuevo, pulsa "Start session" en la barra de ZeroScript y pide lo que quieras.

## Notas
- Si Mobile Studio bloquea HTTP a 127.0.0.1, el plugin no conectara; usa el modo copiar/pegar (ZeroScriptPaste).
- Los textos de ayuda de ZeroScript mencionan "Roblox Studio" de escritorio; ignora esos pasos.
